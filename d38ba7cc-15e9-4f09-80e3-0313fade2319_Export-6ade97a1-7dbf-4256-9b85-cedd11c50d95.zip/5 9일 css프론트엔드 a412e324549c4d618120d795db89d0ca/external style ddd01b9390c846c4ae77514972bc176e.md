# external style

방법 1

외부파일로 css 파일을 만든후, <link>태그로 html 파일에 연결해줘야한다 

![Untitled](external%20style%20ddd01b9390c846c4ae77514972bc176e/Untitled.png)

![Untitled](external%20style%20ddd01b9390c846c4ae77514972bc176e/Untitled%201.png)

방법 2

![Untitled](external%20style%20ddd01b9390c846c4ae77514972bc176e/Untitled%202.png)