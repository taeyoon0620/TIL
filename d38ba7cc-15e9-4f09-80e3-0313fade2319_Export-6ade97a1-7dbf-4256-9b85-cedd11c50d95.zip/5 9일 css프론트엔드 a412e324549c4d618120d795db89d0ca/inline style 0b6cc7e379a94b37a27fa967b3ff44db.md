# inline style

![Untitled](inline%20style%200b6cc7e379a94b37a27fa967b3ff44db/Untitled.png)