# Internal

html 파일안에들어오는 css

![Untitled](Internal%20febd797a531b41689aaacdcffedbcf9f/Untitled.png)